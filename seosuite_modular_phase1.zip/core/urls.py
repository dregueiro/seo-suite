from django.urls import path

from core.views.home import home
from core.views.keywords import keyword_import, keyword_list

urlpatterns = [
    path("", home, name="home"),
    path("keywords/", keyword_list, name="keyword_list"),
    path("keywords/import/", keyword_import, name="keyword_import"),
]
