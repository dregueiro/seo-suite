from __future__ import annotations

from django import forms

from .models import Project, Country, Language


class KeywordImportForm(forms.Form):
    project = forms.ModelChoiceField(
        queryset=Project.objects.all(),
        widget=forms.Select(attrs={"class": "form-select"}),
    )

    country = forms.ModelChoiceField(
        queryset=Country.objects.all().order_by("name"),
        required=False,
        widget=forms.Select(attrs={"class": "form-select"}),
    )
    city = forms.CharField(
        required=False,
        max_length=120,
        widget=forms.TextInput(attrs={"class": "form-control"}),
    )

    language = forms.ModelChoiceField(
        queryset=Language.objects.all().order_by("name"),
        required=False,
        widget=forms.Select(attrs={"class": "form-select"}),
    )
    device = forms.CharField(
        required=False,
        max_length=10,
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "desktop / mobile"}),
    )

    keywords_text = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={"rows": 12, "placeholder": "One keyword per line", "class": "form-control"}),
    )

    csv_file = forms.FileField(required=False)

    def clean(self):
        cleaned = super().clean()
        text = (cleaned.get("keywords_text") or "").strip()
        csv_file = cleaned.get("csv_file")
        if not text and not csv_file:
            raise forms.ValidationError("Paste keywords or upload a CSV file.")
        return cleaned


class KeywordPlannerForm(forms.Form):
    seed_keyword = forms.CharField(
        max_length=255,
        required=True,
        label="Seed keyword",
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "ej: seo tools"}),
    )

    country = forms.ModelChoiceField(
        queryset=Country.objects.all().order_by("name"),
        required=True,
        label="País",
        widget=forms.Select(attrs={"class": "form-select"}),
    )

    language = forms.ModelChoiceField(
        queryset=Language.objects.all().order_by("name"),
        required=True,
        label="Idioma",
        widget=forms.Select(attrs={"class": "form-select"}),
    )

    top_n = forms.IntegerField(
        required=False,
        initial=15,
        min_value=10,
        max_value=15,
        label="Top ideas (10-15)",
        widget=forms.NumberInput(attrs={"class": "form-control"}),
    )

    use_fallback = forms.BooleanField(
        required=False,
        initial=False,
        label="Usar fallback (DataForSEO Labs, costo extra)",
        widget=forms.CheckboxInput(attrs={"class": "form-check-input"}),
    )

    def clean_country(self):
        country = self.cleaned_data["country"]
        if not getattr(country, "dataforseo_location_code", None):
            raise forms.ValidationError("Este país no tiene DataForSEO location_code configurado.")
        return country
