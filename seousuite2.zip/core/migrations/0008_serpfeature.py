# Generated manually on 2026-01-02

from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ("core", "0007_serprun_error_serprun_task_id_alter_client_id_and_more"),
    ]

    operations = [
        migrations.CreateModel(
            name="SerpFeature",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("feature_type", models.CharField(max_length=50)),
                ("payload_json", models.JSONField(blank=True, default=dict)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("serp_run", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="features", to="core.serprun")),
            ],
            options={
                "ordering": ["serp_run_id", "feature_type"],
                "indexes": [models.Index(fields=["serp_run", "feature_type"], name="core_serpfe_serp_ru_9a1234_idx")],
            },
        ),
    ]
