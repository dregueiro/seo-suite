from django.contrib import admin
from .models import (
    Client,
    Project,
    Keyword,
    Country,
    Language,
    SerpRun,
    SerpResult,
    KeywordIdeaRun,
    KeywordIdea,
)
@admin.register(KeywordIdeaRun)
class KeywordIdeaRunAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "project",
        "seed_keyword",
        "location_code",
        "language_code",
        "provider_used",
        "from_cache",
        "is_new_seed",
        "created_at",
    )
    search_fields = ("seed_keyword", "project__name", "project__domain")
    list_filter = ("provider_used", "from_cache", "is_new_seed", "language_code", "location_code", "created_at")

@admin.register(KeywordIdea)
class KeywordIdeaAdmin(admin.ModelAdmin):
    list_display = ("id", "run", "keyword", "search_volume", "competition_index")
    search_fields = ("keyword",)
    list_filter = ("search_volume",)


@admin.register(SerpRun)
class SerpRunAdmin(admin.ModelAdmin):
    list_display = ("id", "project", "provider", "status", "top_n", "total_keywords", "total_results", "created_at")
    list_filter = ("provider", "status", "project")
    search_fields = ("project__name", "project__domain")
    ordering = ("-created_at",)


@admin.register(SerpResult)
class SerpResultAdmin(admin.ModelAdmin):
    list_display = ("serp_run", "keyword", "position", "result_type", "domain", "url")
    list_filter = ("result_type", "serp_run__project", "serp_run__provider")
    search_fields = ("keyword__keyword", "domain", "url", "title")
    ordering = ("-created_at",)

@admin.register(Country)
class CountryAdmin(admin.ModelAdmin):
    list_display = ("name", "code","dataforseo_location_code")
    search_fields = ("name", "code")
    ordering = ("name",)


@admin.register(Language)
class LanguageAdmin(admin.ModelAdmin):
    list_display = ("name", "code")
    search_fields = ("name", "code")
    ordering = ("name",)


@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display = ("name", "created_at")
    search_fields = ("name",)
    ordering = ("name",)


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "client",
        "domain",
        "google_ads_customer_id",
        "is_active",
        "country",
        "language",
        "device",
        "updated_at",
    )
    list_filter = ("is_active", "country", "language", "device")
    search_fields = ("name", "domain", "client__name", "google_ads_customer_id")
    autocomplete_fields = ("client",)



@admin.register(Keyword)
class KeywordAdmin(admin.ModelAdmin):
    list_display = ("keyword", "project", "status", "country", "city", "language", "device", "updated_at")
    list_filter = ("status", "country", "language", "device", "project")
    search_fields = ("keyword", "target_url", "project__name", "project__domain")
    autocomplete_fields = ("project",)
